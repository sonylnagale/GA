//Introducing jQuery
$(function(){
	console.log("Hello world");
  	$('#thumbnails');
  	$('.thumbnail');
 	$('ul');
  	$('ul li');
});