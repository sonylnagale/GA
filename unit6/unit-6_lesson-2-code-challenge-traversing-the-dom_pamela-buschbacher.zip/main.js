$(function() {
//Student Code Start
$('#thumbnails').children('div');
$('#thumbnails').children('div').children('img');
$('#thumbnails').find('.thumbnail');
$('#thumbnails').children();
$('.thumbnail').parent().parent('#thumbnails');
$('.thumbnail').parent('div').next().children('.thumbnail');
$('#thumbnails div:last-child').prev().children('.thumbnail');
});